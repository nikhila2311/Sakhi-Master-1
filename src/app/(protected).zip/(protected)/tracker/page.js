// Tracker.js
'use client';

import Greeting from '@/components/dashboard/Greeting';
import { getUser } from '@/lib/utils'; // Assuming getUser fetches user data including menstrualCycle
import { useSession } from 'next-auth/react';
import React, { useEffect, useState } from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { FaEgg } from 'react-icons/fa6';
import { MdBloodtype } from 'react-icons/md';
import { SiEsbuild } from 'react-icons/si';
import { GiCottonFlower } from 'react-icons/gi';
import { BiLoaderAlt } from 'react-icons/bi';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { db } from '@/config/firebase';
import { doc, setDoc } from 'firebase/firestore/lite';
import { toast } from '@/components/ui/Toast';

export default function Tracker() {
  const { data: sessionData } = useSession();
  const userFirstName = sessionData?.user?.name ? sessionData.user.name.split(' ')[0] : '';
  const email = sessionData?.user?.email;

  const [userFireData, setUserFireData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [menstrualInput, setMenstrualInput] = useState({
    last_period_start_date: '',
    average_cycle_length: '',
    period_duration: '',
  });

  // Fetch user data
  const fetchUserData = async (userEmail) => {
    if (!userEmail) return;
    setLoading(true);
    try {
      const userData = await getUser(userEmail);
      if (userData) {
        setUserFireData(userData);
        if (userData.menstrualCycle) {
          setMenstrualInput({
            last_period_start_date: userData.menstrualCycle.last_period_start_date || '',
            average_cycle_length: userData.menstrualCycle.average_cycle_length || '',
            period_duration: userData.menstrualCycle.period_duration || '',
          });
        }
      } else {
        window.location.href = '/onboarding';
      }
    } catch (error) {
      console.error("Error fetching user data:", error);
      toast.error("Failed to load user data.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (email) {
      fetchUserData(email);
    }
  }, [email]);

  // Calculate phase dates based on input data
  const calculatePhases = () => {
    const { last_period_start_date, average_cycle_length, period_duration } = menstrualInput;

    if (!last_period_start_date || !average_cycle_length || !period_duration) {
      return {
        menstrual_phase: { start_date: 'N/A', end_date: 'N/A' },
        follicular_phase: { start_date: 'N/A', end_date: 'N/A' },
        ovulation_phase: { start_date: 'N/A', end_date: 'N/A' },
        luteal_phase: { start_date: 'N/A', end_date: 'N/A' },
      };
    }

    const cycleLength = parseInt(average_cycle_length);
    const periodDays = parseInt(period_duration);
    if (isNaN(cycleLength) || isNaN(periodDays)) {
      return {
        menstrual_phase: { start_date: 'N/A', end_date: 'N/A' },
        follicular_phase: { start_date: 'N/A', end_date: 'N/A' },
        ovulation_phase: { start_date: 'N/A', end_date: 'N/A' },
        luteal_phase: { start_date: 'N/A', end_date: 'N/A' },
      };
    }

    const startDate = new Date(last_period_start_date);

    // Helper to format date YYYY-MM-DD
    const formatDate = (date) => date.toISOString().split('T')[0];

    // Menstrual phase: last_period_start_date to last_period_start_date + period_duration - 1
    const menstrualStart = startDate;
    const menstrualEnd = new Date(startDate);
    menstrualEnd.setDate(menstrualEnd.getDate() + periodDays - 1);

    // Follicular phase: day after menstrual ends to day before ovulation
    const follicularStart = new Date(menstrualEnd);
    follicularStart.setDate(follicularStart.getDate() + 1);

    // Ovulation day calculated as cycleLength - 14 (typical luteal phase length)
    const ovulationDay = cycleLength - 14 > periodDays ? cycleLength - 14 : 14; // fallback to 14 if smaller than periodDays
    const ovulationStart = new Date(startDate);
    ovulationStart.setDate(startDate.getDate() + ovulationDay - 1);

    const follicularEnd = new Date(ovulationStart);
    follicularEnd.setDate(ovulationStart.getDate() - 1);

    // Ovulation phase: ovulation day only
    const ovulationEnd = new Date(ovulationStart);

    // Luteal phase: day after ovulation to day before next period (cycle length)
    const lutealStart = new Date(ovulationEnd);
    lutealStart.setDate(lutealStart.getDate() + 1);
    const lutealEnd = new Date(startDate);
    lutealEnd.setDate(startDate.getDate() + cycleLength - 1);

    return {
      menstrual_phase: { start_date: formatDate(menstrualStart), end_date: formatDate(menstrualEnd) },
      follicular_phase: { start_date: formatDate(follicularStart), end_date: formatDate(follicularEnd) },
      ovulation_phase: { start_date: formatDate(ovulationStart), end_date: formatDate(ovulationEnd) },
      luteal_phase: { start_date: formatDate(lutealStart), end_date: formatDate(lutealEnd) },
    };
  };

  function getPhaseDates(phase) {
    const phaseData = userFireData?.menstrualCycle?.[phase];
    if (!phaseData?.start_date || !phaseData?.end_date) {
      return 'N/A';
    }
    return `${phaseData.start_date} to ${phaseData.end_date}`;
  }

  const handleMenstrualSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    if (!email) {
      toast.error("User email not found. Please log in again.");
      setSaving(false);
      return;
    }

    // Validate inputs
    const averageCycle = parseInt(menstrualInput.average_cycle_length);
    const periodDuration = parseInt(menstrualInput.period_duration);
    if (isNaN(averageCycle) || isNaN(periodDuration)) {
      toast.error("Please enter valid numbers for cycle length and period duration.");
      setSaving(false);
      return;
    }

    // Calculate phases
    const calculatedPhases = calculatePhases();

    try {
      const userDocRef = doc(db, 'users', email);
      await setDoc(
        userDocRef,
        {
          ...userFireData, // keep existing user data
          menstrualCycle: {
            last_period_start_date: menstrualInput.last_period_start_date,
            average_cycle_length: averageCycle,
            period_duration: periodDuration,
            ...calculatedPhases,
          },
        },
        { merge: true }
      );

      toast.success("Menstrual data saved successfully!");
      await fetchUserData(email);
    } catch (error) {
      console.error("Error saving menstrual data:", error);
      toast.error("Failed to save menstrual data. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className='flex flex-row justify-center items-center p-4 min-h-[calc(100vh-140px)]'>
        <BiLoaderAlt className='text-4xl animate-spin text-pink-500' />
      </div>
    );
  }

  return (
    <div>
      <div className='flex flex-col'>
        <Greeting userFirstName={userFirstName} />
        <hr className='w-full opacity-20' />
        <p className='text-2xl font-semibold text-center text-rose-400'>
          Your Menstrual Tracker
        </p>

        <form onSubmit={handleMenstrualSubmit} className="mt-8 p-4 bg-white shadow-md rounded-md flex flex-col gap-4">
          <h3 className="text-xl font-semibold text-rose-500">Update Your Cycle Data</h3>
          <div className="grid w-full items-center gap-1.5">
            <Label htmlFor="last_period_start_date">Last Period Start Date</Label>
            <Input
              type="date"
              id="last_period_start_date"
              value={menstrualInput.last_period_start_date}
              onChange={(e) => setMenstrualInput({ ...menstrualInput, last_period_start_date: e.target.value })}
              disabled={saving}
              required
            />
          </div>
          <div className="grid w-full items-center gap-1.5">
            <Label htmlFor="average_cycle_length">Average Cycle Length (days)</Label>
            <Input
              type="number"
              id="average_cycle_length"
              value={menstrualInput.average_cycle_length}
              onChange={(e) => setMenstrualInput({ ...menstrualInput, average_cycle_length: e.target.value })}
              disabled={saving}
              required
              min={10}
              max={45}
            />
          </div>
          <div className="grid w-full items-center gap-1.5">
            <Label htmlFor="period_duration">Period Duration (days)</Label>
            <Input
              type="number"
              id="period_duration"
              value={menstrualInput.period_duration}
              onChange={(e) => setMenstrualInput({ ...menstrualInput, period_duration: e.target.value })}
              disabled={saving}
              required
              min={1}
              max={14}
            />
          </div>
          <Button
            type="submit"
            disabled={saving}
            className="bg-rose-500 hover:bg-rose-600 text-white flex items-center justify-center gap-2"
          >
            {saving && <BiLoaderAlt className='text-xl animate-spin' />} Save Cycle Data
          </Button>
        </form>

        {userFireData?.menstrualCycle ? (
          <Accordion type='multiple' collapsible className='mt-8 flex flex-col gap-4'>
            <AccordionItem
              value='item-1'
              className='bg-gradient-to-br from-pink-50 to-pink-100 px-4 rounded-md text-pink-950 shadow-md'
            >
              <AccordionTrigger>
                <p className='flex flex-col gap-2'>
                  <span className='flex items-center gap-1 font-semibold'>
                    <MdBloodtype /> Menstrual Phase (Period)
                  </span>
                  <span className='text-sm ml-5 text-start'>
                    {getPhaseDates('menstrual_phase')}
                  </span>
                </p>
              </AccordionTrigger>
              <AccordionContent>
                Menstruation is commonly known as a period. When you
                menstruate, your uterus lining sheds and flows out of your
                vagina. Your period contains blood, mucus and some cells from
                the lining of your uterus. The average length of a period is
                three to seven days. Sanitary pads, tampons, period underwear
                or menstrual cups can be used to absorb your period. Pads and
                tampons need to be changed regularly (preferably every three
                to four hours) and menstrual cups should be changed every
                eight to 12 hours.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem
              value='item-2'
              className='bg-gradient-to-br from-fuchsia-50 to-fuchsia-100 px-4 rounded-md text-fuchsia-950 shadow-md'
            >
              <AccordionTrigger>
                <p className='flex flex-col gap-2'>
                  <span className='flex items-center gap-1 font-semibold'>
                    <SiEsbuild /> Follicular Phase
                  </span>
                  <span className='text-sm ml-5 text-start'>
                    {getPhaseDates('follicular_phase')}
                  </span>
                </p>
              </AccordionTrigger>
              <AccordionContent>
                The follicular phase starts on the first day of your period
                and lasts for 13 to 14 days, ending in ovulation. The
                pituitary gland in the brain releases a hormone to stimulate
                the production of follicles on the surface of an ovary.
                Usually, only one follicle will mature into an egg. This can
                happen from day 10 of your cycle. During this phase, your
                uterus lining also thickens in preparation for pregnancy.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem
              value='item-3'
              className='bg-gradient-to-br from-zinc-50 to-zinc-100 px-4 rounded-md text-zinc-950 shadow-md'
            >
              <AccordionTrigger>
                <p className='flex flex-col gap-2'>
                  <span className='flex items-center gap-1 font-semibold'>
                    <FaEgg /> Ovulation Phase
                  </span>
                  <span className='text-sm ml-5 text-start'>
                    {getPhaseDates('ovulation_phase')}
                  </span>
                </p>
              </AccordionTrigger>
              <AccordionContent>
                Ovulation is when a mature egg is released from an ovary and
                moves along a fallopian tube towards your uterus. This usually
                happens once each month, about two weeks before your next
                period. Ovulation can last from 16 to 32 hours. It is possible
                to get pregnant in the five days before ovulation and on the
                day of ovulation, but it’s more likely in the three days
                leading up to and including ovulation.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem
              value='item-4'
              className='bg-gradient-to-br from-sky-50 to-sky-100 px-4 rounded-md text-sky-950 shadow-md'
            >
              <AccordionTrigger>
                <p className='flex flex-col gap-2'>
                  <span className='flex items-center gap-1 font-semibold'>
                    <GiCottonFlower /> Luteal Phase
                  </span>
                  <span className='text-sm ml-5 text-start'>
                    {getPhaseDates('luteal_phase')}
                  </span>
                </p>
              </AccordionTrigger>
              <AccordionContent>
                The luteal phase starts after ovulation and lasts about 14
                days. If the egg is not fertilized by sperm, hormone levels
                fall and the lining of the uterus breaks down and your period
                begins. If the egg is fertilized, it implants itself into the
                lining of your uterus and pregnancy begins.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        ) : (
          <p className="mt-6 text-center text-gray-500">No menstrual cycle data available.</p>
        )}
      </div>
    </div>
  );
}
